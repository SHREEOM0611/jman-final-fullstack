{{
    config(
        tags=['mart']
    )
}}
WITH
registrations AS (
    SELECT
        *
    FROM {{ ref('registrations') }}
),

event AS (
    SELECT
     *
    FROM {{ref('event')}}
),

registration_details AS (
    SELECT r.eventr_id, e.name,e.date, e.capacity,r.userr_id, e.domain FROM event as e 
    JOIN registrations as r
    on r.eventr_id=e.event_id
)
,
count_event AS (
    SELECT  domain, userr_id, count(eventr_id) as total_registrations from registration_details
    group by domain,userr_id
)




select * from count_event order by userr_id asc

 