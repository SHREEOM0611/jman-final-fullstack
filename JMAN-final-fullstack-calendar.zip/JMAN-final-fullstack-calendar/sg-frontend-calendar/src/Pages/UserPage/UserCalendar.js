import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Calendar, momentLocalizer } from 'react-big-calendar'
import moment from 'moment'
import 'react-big-calendar/lib/css/react-big-calendar.css';
import { useNavigate } from 'react-router-dom'

const localizer = momentLocalizer(moment);

const UserCalendar = () => {
  const [userDetails, setUserDetails] = useState({});
  const [registeredEvents, setRegisteredEvents] = useState([]);

  const navigate = useNavigate();

  const jwtToken = localStorage.getItem("userToken");

  useEffect(() => {
    const fetchUserDetails = async () => {
      try {
        if (!jwtToken) {
          alert("Please Login!!!");
          navigate("/");
        }

        const config = {
          headers: {
            Authorization: `Bearer ${jwtToken}`,
          },
        };
        const response = await axios.get(
          "http://localhost:3000/user-details",
          config
        );

        setUserDetails(response.data);
      } catch (error) {
        console.error("Failed to fetch user details", error);
      }
    };

    fetchUserDetails();
  }, [jwtToken, navigate]);

  useEffect(() => {
    const fetchRegisteredEvents = async () => {
      try {
        const response = await axios.get(
          `http://localhost:3000/user-event-fetch/${userDetails._id}`
        );
        
        const formattedEvents = response.data.map((event) => {
          const startDate = new Date(event.date + 'T' + event.startTime);
          const endDate = new Date(event.date + 'T' + event.endTime);

          console.log(event)

          return {
            ...event,
            start: startDate,
            end: endDate,
            title: event.name
          };
        });

        
        

        setRegisteredEvents(formattedEvents);
      } catch (error) {
        console.log("Error fetching Registered Events", error);
      }
    };

    fetchRegisteredEvents();
  }, [userDetails]);

  return jwtToken ? (
    <div>
      <Calendar 
        localizer={localizer}
        events={registeredEvents}
        startAccessor="start"
        endAccessor="end"
        style={{ height: 500 }}
      />
    </div>
  ) : (
    <h1 className="text-black text-4xl flex justify-center">
      you are not an user!!!
    </h1>
  )
}

export default UserCalendar
