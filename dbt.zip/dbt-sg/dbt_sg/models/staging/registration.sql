{{
    config(
        tags=['staging']
    )
}}


WITH

registrations AS (

    SELECT

       *

    FROM {{ source('learning_platform', 'REGISTRATION') }}

)
SELECT * FROM registrations