{{
    config(
        tags=['staging']
    )
}}


WITH

interests AS (

    SELECT

       *

    FROM {{ source('learning_platform', 'INTEREST') }}

)
SELECT * FROM interests